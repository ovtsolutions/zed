import sys

__badattr__ = True
moduleattr = sys
