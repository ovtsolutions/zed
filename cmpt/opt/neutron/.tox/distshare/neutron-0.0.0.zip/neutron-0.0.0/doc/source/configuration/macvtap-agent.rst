=================
macvtap_agent.ini
=================

.. show-options::
   :config-file: etc/oslo-config-generator/macvtap_agent.ini
