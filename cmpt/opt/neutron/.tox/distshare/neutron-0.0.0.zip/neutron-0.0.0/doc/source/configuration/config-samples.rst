==========================
Sample Configuration Files
==========================

.. toctree::
   :maxdepth: 1

   samples/neutron.rst

.. toctree::
   :maxdepth: 1

   samples/ml2-conf.rst
   samples/linuxbridge-agent.rst
   samples/macvtap-agent.rst
   samples/openvswitch-agent.rst
   samples/sriov-agent.rst
   samples/ovn.rst

.. toctree::
   :maxdepth: 1

   samples/dhcp-agent.rst
   samples/l3-agent.rst
   samples/metadata-agent.rst
   samples/metering-agent.rst
