=======
ovn.ini
=======

.. show-options::
   :config-file: etc/oslo-config-generator/ovn.ini
