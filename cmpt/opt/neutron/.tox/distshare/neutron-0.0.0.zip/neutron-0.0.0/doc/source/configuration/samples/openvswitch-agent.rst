============================
Sample openvswitch_agent.ini
============================

This sample configuration can also be viewed in `the raw format
<../../_static/config-samples/openvswitch_agent.conf.sample>`_.

.. literalinclude:: ../../_static/config-samples/openvswitch_agent.conf.sample
