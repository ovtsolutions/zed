========================
Sample macvtap_agent.ini
========================

This sample configuration can also be viewed in `the raw format
<../../_static/config-samples/macvtap_agent.conf.sample>`_.

.. literalinclude:: ../../_static/config-samples/macvtap_agent.conf.sample
