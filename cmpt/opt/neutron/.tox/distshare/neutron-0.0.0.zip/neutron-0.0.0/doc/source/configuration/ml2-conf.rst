============
ml2_conf.ini
============

.. show-options::
   :config-file: etc/oslo-config-generator/ml2_conf.ini
