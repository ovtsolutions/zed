===================================
 Newton Series Release Notes
===================================

.. release-notes::
   :branch: stable/newton
   :earliest-version: 9.0.0
